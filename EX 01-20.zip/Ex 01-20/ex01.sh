echo "Enter value of a";
read a
echo "Enter value of b";
read b
c= expr $a + $b

echo $c