echo "Enter First String"
read str1

echo "Enter Second String"
read str2

str3="$str1 $str2"

echo "After concate $str3"