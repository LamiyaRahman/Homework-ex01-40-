echo "Enter a String"
read st
echo "${#st} is the length of your string"