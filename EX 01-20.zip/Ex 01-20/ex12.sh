echo "Enter a Number";
read a
for i in 1 2 3 4 5 6 7 8 9 10
do
t=$(( $a * $i ))
echo $t
i=$(( $i + 1 ))
done