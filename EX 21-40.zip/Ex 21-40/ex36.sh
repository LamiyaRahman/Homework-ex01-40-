 Pwd
 clear 
 date
 mkdir
 cd 
mkdir d1 
cd d1 
 touch file1 file2 
chmod 644 file1 file2 
Is