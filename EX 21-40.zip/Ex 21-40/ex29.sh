str1="AIUB"
str2="AIUB"
if [ $str1 == $str2 ]
then
echo "String are same"
else
echo "String are not same"
fi