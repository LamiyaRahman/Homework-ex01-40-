echo "enter the value of n"
read n
i=1
while [ $i -le $n ]
do
echo -n " $i "
i=$(( $i + $i ))

done
echo ""