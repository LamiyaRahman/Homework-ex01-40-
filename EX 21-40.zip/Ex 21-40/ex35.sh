echo "Enter information in file"

cat > file.txt

cat file.txt |tr '[:lower:]' '[:upper:]'